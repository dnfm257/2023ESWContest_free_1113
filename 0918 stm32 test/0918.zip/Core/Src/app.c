/*
 * app.c
 *
 *  Created on: Sep 18, 2023
 *      Author: iot22
 */


#include "main.h"
#include "app.h"
#include "string.h"
#include "stdio.h"
#include "cmsis_os.h"

#define Total 10
#define CMD_SIZE 60
#define Wpin GPIO_PIN_13
#define Wpin_port GPIOF
#define trig GPIO_PIN_5
#define trig_port GPIOA
#define in_sensor GPIO_PIN_7
#define in_sensor_port GPIOC
#define out_sensor GPIO_PIN_0
#define out_sensor_port GPIOE

char sendBuf[CMD_SIZE];
char recvBuf[CMD_SIZE];

int a=0,b=0,c=0,d1=0,d2=0;
int cds=0;
int n=0,n1=0;
int i=0,o=0;
int IN=0,OUT=0;
int val = 0;
int R;
uint32_t  INTime = 0;
uint32_t  OUTTime = 0;
uint32_t  checkTime = 0;
uint32_t  setTime = 0;
uint32_t  wwTime = 0,wwTime2 = 0;
uint32_t  delayTime = 0,delay2Time=0;
int distance=0, duration=0;
int Y=0;
//pa5==trig
//pc7==in sensor
//pe0 == out sensor
//pf13==w sensor
void call(void);
void equal(void);
void not_equal(void);
void Count_Person(void);
void Delay(void);

void app(void)
{
	call();
}
void call(void)
{
	setTime=HAL_GetTick();
	HAL_GPIO_EXTI_Callback(in_sensor);
	HAL_GPIO_EXTI_Callback(out_sensor);
	HAL_GPIO_EXTI_Callback(Wpin);
}
void Count_Person(void)
{
	printf("cp\n");
	not_equal();
	equal();
	R=(((float)n/(float)Total)*100);
	printf("R: %d\n",R);
}

void insensor(void)
{
	i++;
	INTime = HAL_GetTick();
	Delay();
	printf("i= \n");
	printf("i = %d	o = %d n = %d\n",i,o,n);
	//echo1();
}
void outsensor(void)
{
	o++;
	OUTTime = HAL_GetTick();
	Delay();
	printf("o= \n");
	printf("i = %d	o = %d n = %d\n",i,o,n);
}
void emergency(void)
{
	if(n>0)
	{
		printf("[%s]emergency@%d\n", "119", n);
	}
	else
	{
		printf("flood\n");
	}
}
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	  if(GPIO_Pin == in_sensor)
	  {
	    HAL_GPIO_WritePin(GPIOB, LD3_Pin, GPIO_PIN_SET);
	    insensor();
	    HAL_GPIO_WritePin(GPIOB, LD3_Pin, GPIO_PIN_RESET);
	  }
	  else if(GPIO_Pin == out_sensor)
	  {
		HAL_GPIO_WritePin(GPIOB, LD2_Pin, GPIO_PIN_SET);
		outsensor();
		HAL_GPIO_WritePin(GPIOB, LD2_Pin, GPIO_PIN_RESET);
	  }
	  else if(GPIO_Pin == Wpin)
	  {
		printf("w_sensor\n");
	  	HAL_GPIO_WritePin(GPIOB, LD1_Pin, GPIO_PIN_SET);
	  	HAL_GPIO_WritePin(GPIOB, LD1_Pin, GPIO_PIN_RESET);

	  	emergency();
	  	printf("wsensor\n");
	  }
}
void not_equal(void)
{
	checkTime = HAL_GetTick();
	   // 만약 측정이 잘못된 이후 사람의 출입이 있었다면 나오는 오류 수정 필요 08/31
	printf("not equal\n");
	      if(i<o) // 들어가려다 나옴 = 들어가지 않음
	      {
	        if((checkTime-OUTTime)>5000)//이동이 없음= 센서오류
	        {
	          o--;
	          INTime=0;
	          OUTTime=0;
	          printf("not equal : o--\n");
	        }
	      }
	      else if(i>o) // 나가려다 들어옴 = 나가지 않음
	      {
	        if((checkTime-INTime)>5000)
	          {

	              i--;
	              INTime=0;
	              OUTTime=0;
	              printf("not equal : i--\n");
	          }
	      }
}
void equal(void)
{
	//fix_order();
	    if(OUTTime<INTime)
	    {
	      INTime=0;
	      OUTTime=0;

	      HAL_GPIO_WritePin(GPIOB, LD3_Pin,GPIO_PIN_SET);
	      HAL_GPIO_WritePin(GPIOB, LD1_Pin, GPIO_PIN_RESET);
	      n--;
	      printf("n--\n");

	      if(n < 0) // 인원 수 보정
	        n = 0;
	    }
	    else if(OUTTime>INTime)
	    {
	      INTime=0;
	      OUTTime=0;

	     HAL_GPIO_WritePin(GPIOB, LD1_Pin,GPIO_PIN_SET);
	     HAL_GPIO_WritePin(GPIOB, LD3_Pin, GPIO_PIN_RESET);

	      n++;
	      printf("n++\n");
	    }
}

void Delay(void)
{
	printf("delay start\n");
	wwTime = HAL_GetTick();
	while((wwTime2-wwTime)>5000)
	{
		printf("1");
		wwTime2 = HAL_GetTick();
	}
	printf("delay end\n");
}

/*void echo1(void) //에코값 받아오기
{

	volatile uint32_t curr = HAL_GetTick();
	if(curr - prev > 250){
		HAL_GPIO_WritePin(TRIG_PORT, TRIG_PIN, GPIO_PIN_SET);
	__HAL_TIM_SET_COUNTER(&htim2, 0);
	if (__HAL_TIM_GET_COUNTER (&htim2) < 10);  // wait for 10 us
	HAL_GPIO_WritePin(TRIG_PORT, TRIG_PIN, GPIO_PIN_RESET);

		pMillis = HAL_GetTick();
		while (!(HAL_GPIO_ReadPin (ECHO_PORT, ECHO_PIN)) && pMillis + 10 >  HAL_GetTick());
		val1 = __HAL_TIM_GET_COUNTER (&htim3);

		pMillis = HAL_GetTick();
		while ((HAL_GPIO_ReadPin (ECHO_PORT, ECHO_PIN)) && pMillis + 50 > HAL_GetTick());
		val2 = __HAL_TIM_GET_COUNTER (&htim3);

		distance = (val2-val1)*0.34/2;
		sprintf(string,"%d.%d cm", distance/10, distance%10);
		printf("Distance: %s\r\n", string);

		prev = curr;
	}
	d1=HAL_GPIO_ReadPin(trig_port,trig);
	HAL_Delay(10);
	d2=HAL_GPIO_ReadPin(trig_port,trig);
	duration = pulseIn (ECHO, HIGH);
	distance = duration * 17 / 1000; //거리계산
	idt1=distance;
	Y=1;
	delayTime=millis();
}
void echo2(void) //에코값 비교하기
{
	d1=HAL_GPIO_ReadPin(trig_port,trig);
	HAL_Delay(10);
	d2=HAL_GPIO_ReadPin(trig_port,trig);
	duration = pulseIn (ECHO, HIGH);//
	distance = duration * 17 / 1000; //거리계산
	idt2=distance;
	Y=0;
}*/
/*if(Y==1)//outsensor에서 감지
	{
		delay2Time=millis();
	    if((delay2Time-delayTime)>1000) //1000millis이후에 측정
	    {
	      echo2();
	      delayTime=0;
	    }*/

/*
void fix_order()// 값이 정상적이지 않으면
{
  if(n!=n1) //값이 다르면 관리자 호출
  {
    sprintf(sendBuf, "[%s]CP error@%d,%d\n", "KSH_STM", n,n1);
    BTSerial.write(sendBuf);
  }
}

void aaa() //비교 함수
{
  if(idt1<idt2)//in센서가 마지막
  {
    n1++;
  }
  else if(idt2<idt1)
  {
    n1--;
  }
}


// 인원체크(재실측정) 함수
void CP()
{
  if(Y==1)//outsensor에서 감지
  {
    delay2Time=millis();
    if((delay2Time-delayTime)>1000) //1000millis이후에 측정
    {
      echo2();
      delayTime=0;
    }

  }
//idt1과 idt2로 값의변화를 측정

    // 데이터 전송
    if(setTime % 100)
    {
      Serial.print("val= ");
      Serial.println(val);

      if(val<300)
      {
        sprintf(sendBuf, "[%s]AAA@%d\n", recvId, R);
        BTSerial.write(sendBuf);
        delay(5);
        sprintf(sendBuf, "[%s]AAA@%d\n", "KSH_STM", R);
        BTSerial.write(sendBuf);
      }
      else if(val>300)
      {
        sprintf(sendBuf, "[%s]flood\n", recvId);
        BTSerial.write(sendBuf);
        delay(5);
        sprintf(sendBuf, "[%s]flood\n", "KSH_STM");
        BTSerial.write(sendBuf);
      }
    }
  }
}

void emergency()
{
  int k;

  Serial.begin(115200); // 부저 출력을 위한 변경
  for(k=0;k<n;k++) //부저 이벤트
  {
    tone(Buzzer1, 261);// send pulse
    delay (1) ;// delay 1ms
    noTone(Buzzer1);
    delay (1) ;
  }

  Serial.begin(9600); //통신을 위한 변경

  sprintf(lcdLine1, "emergency : %d", i);
  sprintf(lcdLine2, " emergency : %d", o);
  lcdDisplay(0, 0, lcdLine1);
  lcdDisplay(0, 1, lcdLine2);

  sprintf(sendBuf, "[%s]emergency@%d\n", "119", n);
  BTSerial.write(sendBuf);

  delay(5);
  sprintf(sendBuf, "[%s]emergency@%d\n", "order", n);
  BTSerial.write(sendBuf);
  sprintf(sendBuf, "[%s]emergency@%d\n", "HC_COM", n);
  BTSerial.write(sendBuf);
  sprintf(sendBuf, "[%s]emergency@%d\n", "KSH_STM", n);
  BTSerial.write(sendBuf);
  delay(500);
}

void lcdDisplay(int x, int y, char * str)
{
  int len = 16 - strlen(str);
  lcd.setCursor(x, y);
  lcd.print(str);
  for (int i = len; i > 0; i--)
    lcd.write(' ');
}*/

